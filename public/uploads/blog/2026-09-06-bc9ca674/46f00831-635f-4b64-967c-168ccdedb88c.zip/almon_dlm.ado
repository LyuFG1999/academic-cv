capture program drop almon_dlm
*! Almon method for distributed lag model estimation
program define almon_dlm, nclass
    * Parse input arguments
    syntax varlist(min=2) [if] [in] [, m(integer 1) lags(integer 1)  pic(integer 0)]

    * Check if the inputs are valid
    if `m' < 1 {
        display as error "Error: The polynomial degree m must be >= 1"
        exit 1
    }
    if `lags' < 1 {
        display as error "Error: The number of lags i must be >= 1"
        exit 1
    }

    * Extract variables from varlist
    //local yvar = `varlist'[1]           // Dependent variable
	local yvar : word 1 of `varlist'
	
    //local xvar = `varlist'[2]           // Core independent variable
	local xvar : word 2 of `varlist'
	
    //local controls : list varlist[3, _N] // Control variables
	//local xx3_to_last : subinstr local x "`: word 1 of `x'' `: word 2 of `x'' " "" , all
	local controls : subinstr local varlist "`: word 1 of `varlist'' `: word 2 of `varlist'' " "" , all
	
   qui  gen vaild_var = 1
	
	*missing variables
	foreach var of varlist `yvar' `xvar' `controls' {
	qui replace vaild_var = 0 if `var' == .
	}
	
    * Create lagged variables for core independent variable
    forval j = 1/`lags' {
        qui gen `xvar'_lag`j' = L`j'.`xvar'
		qui replace vaild_var = 0 if `xvar'_lag`j' == .
    }
    
    * Construct the polynomial terms for Almon lag distribution
	local expression "{gamma_0}*`xvar'"
	forvalues i = 1/`lags' {
		local expression_temp "{gamma_0}"
		forvalues k = 1/`m' {
			local num ""
			local num = `i'^`k'
			local expression_temp "`expression_temp' + {gamma_`k'} * `num'"
		}
		local expression " `expression' + (`expression_temp')*`xvar'_lag`i' "
	}

	local expression_xvar "+ `expression' "
	
	*Construct the controls
	local expression_control ""
	foreach var of local controls {
		local expression_control "`expression_control' + {`var'}*`var'"
	}

    * Run the regression including polynomial lagged terms and controls
    // 调整 reg `yvar' `poly_terms' `controls' `if' `in'
	if "`if'" == "" {
	nl ( `yvar' = {constant} `expression_xvar' `expression_control') if vaild_var `in', noconstant
	}
	else {
	nl ( `yvar' = {constant} `expression_xvar' `expression_control') `if' & vaild_var `in' , noconstant
	}
    
	*drop variable
	drop vaild_var 
	forval j = 1/`lags' {
        drop `xvar'_lag`j' 
	}
		
	if `pic' > 0 {
	capture gen lags = `lags'*_n/(_N)
	capture replace ags = `lags'*_n/(_N)
	
    capture gen beta = 0
	capture replace beta = 0
    forv m_j = 0/`m' {
	gen gamma_`m_j'_term = _b[/gamma_`m_j']*(lags^`m_j')
	qui replace beta = beta + gamma_`m_j'_term
	qui drop gamma_`m_j'_term
	}
		}
	
end