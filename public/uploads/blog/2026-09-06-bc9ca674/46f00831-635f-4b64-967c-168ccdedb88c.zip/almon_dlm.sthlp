{smcl}
{* *! English help file 07sep2026; for the supplied almon_dlm.ado}
{title:Title}

{p 4 8 2}
{cmd:almon_dlm} {hline 2} Almon polynomial distributed lag model

{marker syntax}{...}
{title:Syntax}

{p 8 12 2}
{cmd:almon_dlm} {it:depvar} {it:xvar} [{it:controls}]
{ifin}
[{cmd:,} {opt m(#)} {opt lags(#)} {opt pic(#)}]

{p 4 4 2}
The first variable is the dependent variable. The second is the main explanatory
variable whose lag coefficients follow a polynomial. Remaining variables enter
as contemporaneous controls. Use full names of numeric variables. Factor-variable
notation, time-series operators in the input varlist, and weights are not supported.

{p 4 4 2}
Declare the time structure using {help tsset} or {help xtset} before estimation.
Lags are generated using Stata's L operator and follow the declared time interval,
rather than simply taking values from the preceding row. A panel declaration
allows lags to be generated within panels, but estimation is pooled and does not
automatically include individual fixed effects.

{p 4 4 2}
{bf:Current-version note:} Although the syntax accepts two variables, the code
contains a control-variable parsing defect for that case. Fix the parser before
estimating a model without controls. All examples below include an actual control
variable. See {help almon_dlm##limits:Known limitations}.

{marker model}{...}
{title:Model and interpretation}

{p 4 4 2}
Let q = lags() and p = m(). The model includes the current value of the main
explanatory variable and its first q lags:

{p 8 8 2}
y_t = a + sum(j=0,...,q) beta_j x_(t-j) + sum(r) delta_r z_(r,t) + u_t

{p 4 4 2}
The Almon restriction expresses each lag coefficient as a polynomial of degree p
in the lag index j:

{p 8 8 2}
beta_j = gamma_0 + gamma_1*j + ... + gamma_p*j^p, j = 0,...,q.

{p 4 4 2}
Thus, beta_0 = gamma_0. Controls are neither automatically lagged nor subject to
polynomial restrictions. The model includes an intercept named constant;
the {cmd:noconstant} option in the internal {cmd:nl} call does not remove this intercept.

{p 4 4 2}
The command uses {help nl} to estimate gamma_0 through gamma_p, constant, and the
control coefficients. The expression is linear in its parameters. With a full-rank
design matrix and a converged solution, it is equivalent to least-squares
estimation using polynomial-transformed explanatory variables. The reported
gamma parameters are not the individual lag effects; recover beta_j using the formula above.

{p 4 4 2}
Usually, choose 1 <= p <= q. Dimensionality is reduced relative to q+1 unrestricted
lag coefficients only when p < q. When p = q, the polynomial can represent any
set of q+1 lag coefficients. When p > q, the gamma parameters are not uniquely
identified. Even with p <= q, sufficient usable observations and a full-rank
design matrix are required. The command does not select the polynomial degree or
lag length automatically and does not impose zero endpoint restrictions.

{marker options}{...}
{title:Options}

{phang}
{opt m(#)} specifies the polynomial degree as an integer greater than or equal to 1.
The default is {cmd:m(1)}. The program checks the lower bound only; it does not
check whether the degree exceeds {cmd:lags()}.

{phang}
{opt lags(#)} specifies the maximum lag length as an integer greater than or equal
to 1. The default is {cmd:lags(1)}. For example, {cmd:lags(4)} includes x_t,
x_(t-1), ..., x_(t-4), for a total of five terms.

{phang}
{opt pic(#)} accepts an integer and defaults to {cmd:pic(0)}. A positive value
generates plotting variables {cmd:lags} and {cmd:beta} in the current dataset
after estimation. A nonpositive value skips this step. All positive values have
the same meaning. This option does not draw a graph or generate confidence intervals.

{p 8 8 2}
When no conflicting variables exist, the horizontal coordinate is
{cmd:lags = q*_n/_N}, and {cmd:beta} is the polynomial evaluated at that coordinate.
The grid uses all observations, generally contains noninteger lag values, and
runs from q/_N to q, excluding zero. These values are not observation-specific
predictions and are not restricted to the estimation sample. See below for
issues involving repeated calls and existing variables.

{title:Sample and results}

{p 4 4 2}
{cmd:if} and {cmd:in} restrict the regression sample, but lag variables are generated
using the full dataset first. Consequently, lagged values for observations within
a selected interval can come from periods before that interval. Missing values
in the dependent variable, explanatory variables, or required lags affect the
usable sample. The first q periods of each series and observations near time gaps
may be excluded.

{p 4 4 2}
After successful completion, inspect the estimation results left by the underlying
{cmd:nl} call with:

{p 8 8 2}{cmd:ereturn list}{p_end}
{p 8 8 2}{cmd:matrix list e(b)}{p_end}
{p 8 8 2}{cmd:matrix list e(V)}{p_end}

{p 4 4 2}
Refer to parameters as {cmd:_b[/gamma_0]}, {cmd:_b[/gamma_1]}, ...,
and {cmd:_b[/constant]}. Control coefficients use the variable name, for example,
{cmd:_b[/z]}. The wrapper is declared {cmd:nclass} and defines no separate stored
results. It does not automatically return a table of individual lag effects,
a cumulative effect, or model-selection statistics.

{marker examples}{...}
{title:Examples}

{p 4 4 2}
The following simulation clears the data in memory; save any current data first.
It includes a control variable z to avoid the current two-variable parsing defect.

{p 8 8 2}{cmd:clear}{p_end}
{p 8 8 2}{cmd:set seed 20260907}{p_end}
{p 8 8 2}{cmd:set obs 200}{p_end}
{p 8 8 2}{cmd:generate t = _n}{p_end}
{p 8 8 2}{cmd:tsset t}{p_end}
{p 8 8 2}{cmd:generate x = rnormal()}{p_end}
{p 8 8 2}{cmd:generate z = rnormal()}{p_end}
{p 8 8 2}{cmd:generate y = 1 + .5*x + .4*L.x + .3*L2.x + .2*L3.x + .1*L4.x + .3*z + rnormal()}{p_end}
{p 8 8 2}{cmd:almon_dlm y x z, m(2) lags(4)}{p_end}

{p 4 4 2}
Restrict the time interval for observations of the dependent variable:

{p 8 8 2}{cmd:almon_dlm y x z if t >= 30 & t <= 180, m(2) lags(4)}{p_end}

{p 4 4 2}
For a quadratic polynomial, recover the contemporaneous effect and the effects at
lags 1 and 2, together with their standard errors and confidence intervals:

{p 8 8 2}{cmd:nlcom (beta0: _b[/gamma_0]) (beta1: _b[/gamma_0] + _b[/gamma_1] + _b[/gamma_2]) (beta2: _b[/gamma_0] + 2*_b[/gamma_1] + 4*_b[/gamma_2])}{p_end}

{p 4 4 2}
For m = 2 and q = 4, the cumulative effect across lags 0 through 4 is
5*gamma_0 + 10*gamma_1 + 30*gamma_2:

{p 8 8 2}{cmd:nlcom (cumulative: 5*_b[/gamma_0] + 10*_b[/gamma_1] + 30*_b[/gamma_2])}{p_end}

{p 4 4 2}
For a permanent one-unit increase in x, this sum is the effect after all lagged
adjustments have occurred in this model without a lagged dependent variable.
Adjust the expression when q or p changes. In general, the cumulative effect is
sum(j=0,...,q) sum(k=0,...,p) gamma_k*j^k, with the k=0 term defined as gamma_0.

{p 4 4 2}
Generate data for a smooth lag curve and draw the graph manually. The
{cmd:confirm new variable} commands check for existing names. If either check
fails, save or rename the existing variable before continuing:

{p 8 8 2}{cmd:confirm new variable lags}{p_end}
{p 8 8 2}{cmd:confirm new variable beta}{p_end}
{p 8 8 2}{cmd:almon_dlm y x z, m(2) lags(4) pic(1)}{p_end}
{p 8 8 2}{cmd:twoway line beta lags, sort xtitle("Lag") ytitle("Lag coefficient") yline(0)}{p_end}

{p 4 4 2}
The horizontal grid excludes zero. Read the contemporaneous effect separately
from {cmd:_b[/gamma_0]}.

{marker limits}{...}
{title:Known limitations of the current implementation}

{phang}
1. {bf:Parsing fails when only two variables are supplied.}
The code extracts controls by removing the dependent variable name, a space,
the main explanatory variable name, and a trailing space. With only two variables,
the trailing space is generally absent. The original varlist therefore remains
in controls, incorrectly adding the dependent variable and main explanatory
variable as control terms. Do not interpret results from this specification.
Fix the parser before fitting a model without controls; do not add arbitrary
controls solely to bypass the defect.

{phang}
2. {bf:Intermediate variables have fixed names.}
The program creates {cmd:vaild_var} (spelled this way in the source) and
{it:xvar}{cmd:_lag1} through {it:xvar}{cmd:_lagq}, then drops them after successful
estimation. Existing variables with these names cause errors. A long main-variable
name can also make generated names exceed Stata's name-length limit. Errors during
estimation may leave intermediate variables behind. Inspect them before rerunning
and remove only variables generated by the failed call.

{phang}
3. {bf:Repeated use of pic() can produce incorrect results.}
If {cmd:lags} already exists, {cmd:capture} suppresses the generation error.
The next statement mistakenly uses {cmd:replace ags = ...}, so the existing
{cmd:lags} is not updated and an existing variable named {cmd:ags} may be modified.
An existing numeric {cmd:beta} is reset and overwritten. The plotting step also
uses {cmd:gamma_0_term} through {cmd:gamma_p_term}; existing variables with these
names cause errors. Check for all these name conflicts before using {cmd:pic(1)}.

{phang}
4. {bf:The sample flag explicitly checks only ordinary missing values.}
The code uses {cmd:== .}, which does not cover extended missing values .a through .z.
Do not treat the intermediate flag as a complete definition of the final sample;
the underlying {cmd:nl} call also determines how observations are handled.

{phang}
5. {bf:Additional estimation options are not passed through.}
Only {cmd:m()}, {cmd:lags()}, and {cmd:pic()} are accepted. Robust, clustered, or
HAC standard errors, optimization options, and an intercept-free specification
cannot be requested directly. The default output does not automatically correct
for serial correlation in the errors.

{phang}
6. {bf:Prediction requires the original model variables.}
Generated lag variables are dropped on normal completion. Commands such as
{cmd:predict} that require the original expression may therefore fail. For
prediction, recreate all lag variables with the same names and time declaration,
and consult {help nl postestimation} for the relevant command requirements.
The {cmd:nlcom} examples above use coefficients and their covariance matrix and
do not require the lag variables.

{title:Installation and access}

{p 4 4 2}
Place {cmd:almon_dlm.sthlp} and {cmd:almon_dlm.ado} in the same folder on Stata's
search path. If the folder is not already on the search path, run:

{p 8 8 2}{cmd:adopath ++ "D:/OneDrive/Data/Appendix/Programming/stata-ado"}{p_end}
{p 8 8 2}{cmd:help almon_dlm}{p_end}

{p 4 4 2}
This help file documents the supplied source code and is saved as UTF-8 text.

{title:Also see}

{p 4 4 2}
{help nl}, {help nl postestimation}, {help nlcom}, {help tsset}, {help xtset},
{help tsvarlist}.
For SMCL conventions and postestimation usage, see the official Stata documentation:
{browse "https://www.stata.com/manuals17/u.pdf":Stata User's Guide};
{browse "https://www.stata.com/manuals/rnlpostestimation.pdf":nl postestimation}.
